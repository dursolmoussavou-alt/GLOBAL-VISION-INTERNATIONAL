-- GVI International — Migration de sécurité
-- À exécuter dans Supabase > SQL Editor si la base existe déjà.
-- Objectif : empêcher un collaborateur de lire toute la base des colis.

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin' and approved = true
  );
$$;

alter table public.parcels enable row level security;

drop policy if exists "approved users read parcels" on public.parcels;
drop policy if exists "approved users read own parcels" on public.parcels;

create policy "approved users read own parcels" on public.parcels
for select to authenticated
using (
  public.is_admin()
  or (created_by = auth.uid() and exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.approved = true
  ))
);

-- Vérification : en étant connecté comme collaborateur, cette requête
-- ne doit retourner que ses propres colis.
-- select id, client, destination, created_by from public.parcels;
