# GVI International — Gestion des colis

## V1.3 — Gestion professionnelle + base de données en ligne

Cette version part de la V1.2 et conserve son interface, son QR Code simplifié et ses fonctions principales. Elle ajoute une architecture prête pour une vraie utilisation multi-appareils avec **Supabase (PostgreSQL + Auth + RLS)**.

### Nouvelles fonctions
- Modification des colis
- Suppression des colis réservée à l'administrateur
- Recherche avancée : texte, statut, destination, dates, poids min/max
- Fiche colis professionnelle
- Changement de statut avec contrôle des droits
- QR Code simplifié : Nom, Numéro, Provenance, Destination, Prix total, Poids
- Base en ligne Supabase quand `config.js` est renseigné
- Mode local de secours si Supabase n'est pas configuré
- Identifiant automatique `GVI-YYMMDD-00001` en ligne via fonction PostgreSQL
- Tarifs stockés en ligne
- Authentification Supabase en mode en ligne
- Contacts et horaires GVI intégrés
- Bouton TikTok configurable dans `config.js`
- Export CSV et sauvegarde JSON
- Responsive téléphone / ordinateur

## Mise en ligne de la base de données

1. Créez un projet Supabase.
2. Ouvrez **SQL Editor** et exécutez tout le fichier `schema.sql`.
3. Dans Supabase > Authentication, créez le premier compte administrateur.
4. Copiez son UUID puis exécutez dans SQL Editor :

```sql
update public.profiles
set role = 'admin', approved = true
where id = 'UUID-DU-COMPTE';
```

5. Ouvrez `config.js` et renseignez :

```js
window.GVI_CONFIG = {
  SUPABASE_URL: "https://VOTRE-PROJET.supabase.co",
  SUPABASE_ANON_KEY: "VOTRE-PUBLISHABLE-OU-ANON-KEY",
  TIKTOK_URL: "https://www.tiktok.com/",
  COMPANY: { ... }
};
```

6. Envoyez tous les fichiers du dossier sur GitHub Pages / Netlify.

### Sécurité des exports
- L’export CSV est réservé au rôle `admin` et est bloqué par un contrôle d’autorisation directement dans la fonction d’export, même si un collaborateur tente de l’appeler depuis la console du navigateur.
- La sauvegarde JSON est également réservée à l’administrateur.
- Le bouton d’export n’est affiché que dans l’espace Administration, lui-même protégé par le rôle `admin`.
- **Important :** dans une application web, masquer un bouton ne constitue pas à lui seul une protection contre l’extraction des données. La version actuelle charge les colis autorisés dans le navigateur du collaborateur pour permettre leur consultation. Pour empêcher techniquement toute copie massive par un collaborateur, il faut également limiter les données renvoyées par la base (par exemple aux seuls colis nécessaires à son périmètre) ou passer par une API serveur avec contrôle d’autorisation.

### Sécurité
La clé utilisée côté navigateur doit être la clé publique/publishable/anon de Supabase, **jamais** une `service_role` key. Les permissions de lecture/écriture/suppression sont protégées par les politiques Row Level Security du fichier `schema.sql`.

### Comptes collaborateurs
En mode en ligne, les comptes sont créés dans **Supabase Authentication**. Le profil associé est créé automatiquement par le trigger SQL. Le rôle et l'approbation sont stockés dans `profiles`.

- `admin` : accès complet et suppression des colis.
- `collaborator` : accès aux colis approuvés et modification de ses propres colis.

### Contacts GVI
- +212 669 310 646
- +225 07 1181 4583
- +228 9865 9716
- +229 97 86 84 87
- Horaires : 09H–18H, lundi à vendredi ; week-end sur cas exceptionnel.

Le lien TikTok se modifie dans `config.js` dès que vous avez l'URL exacte de votre page.

## Test immédiat sans base
Si vous ne renseignez pas Supabase dans `config.js`, l'application fonctionne en mode local avec :

- Email : `admin@gvi-international.ma`
- Mot de passe : `admin123`

Les données locales restent dans le navigateur. Elles ne sont pas partagées entre appareils tant que Supabase n'est pas configuré.
