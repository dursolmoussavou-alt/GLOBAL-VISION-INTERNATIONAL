GVI V1.3 - LOGO FIX

Le logo est fourni à deux emplacements :
- assets/gvi-logo.jpg (source principale)
- gvi-logo.jpg (fallback)

Ne supprimez aucun de ces fichiers lors de l’envoi sur GitHub/Netlify.
Le JavaScript utilise une URL absolue calculée depuis la page pour que le logo fonctionne aussi sur l’étiquette imprimée ouverte dans une nouvelle fenêtre.
