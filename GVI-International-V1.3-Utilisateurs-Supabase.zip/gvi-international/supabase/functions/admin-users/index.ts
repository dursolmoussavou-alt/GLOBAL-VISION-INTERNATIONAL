import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Méthode non autorisée.' }, 405)

  const authHeader = req.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) return json({ error: 'Authentification requise.' }, 401)

  const anonKey = Deno.env.get('SUPABASE_ANON_KEY') ?? ''
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? ''
  if (!anonKey || !serviceKey || !supabaseUrl) return json({ error: 'Configuration serveur Supabase incomplète.' }, 500)

  const token = authHeader.replace('Bearer ', '')
  const userClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: `Bearer ${token}` } } })
  const { data: { user }, error: userError } = await userClient.auth.getUser(token)
  if (userError || !user) return json({ error: 'Session administrateur invalide.' }, 401)

  const adminClient = createClient(supabaseUrl, serviceKey)
  const { data: actor, error: actorError } = await adminClient
    .from('profiles').select('id,role,approved').eq('id', user.id).single()
  if (actorError || actor?.role !== 'admin' || actor?.approved !== true) {
    return json({ error: 'Accès administrateur requis.' }, 403)
  }

  try {
    const body = await req.json()
    const action = body?.action ?? 'create'

    if (action === 'list') {
      const { data: profiles, error: profilesError } = await adminClient
        .from('profiles').select('id,full_name,role,approved,created_at').order('created_at', { ascending: false })
      if (profilesError) return json({ error: profilesError.message }, 400)
      const { data: authUsers, error: authError } = await adminClient.auth.admin.listUsers({ page: 1, perPage: 1000 })
      if (authError) return json({ error: authError.message }, 400)
      const emails = new Map((authUsers.users || []).map(u => [u.id, u.email || '']))
      const users = (profiles || []).map(p => ({ ...p, name: p.full_name || '—', email: emails.get(p.id) || '' }))
      return json({ users })
    }

    if (action === 'create') {
      const name = String(body?.full_name ?? '').trim()
      const email = String(body?.email ?? '').trim().toLowerCase()
      const password = String(body?.password ?? '')
      const role = body?.role === 'admin' ? 'admin' : 'collaborator'
      const approved = body?.approved !== false

      if (!name) return json({ error: 'Le nom complet est obligatoire.' }, 400)
      if (!email || !email.includes('@')) return json({ error: 'Adresse email invalide.' }, 400)
      if (password.length < 6) return json({ error: 'Le mot de passe doit contenir au moins 6 caractères.' }, 400)

      const { data: created, error: createError } = await adminClient.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: { full_name: name },
      })
      if (createError) return json({ error: createError.message }, 400)
      if (!created.user) return json({ error: 'Utilisateur non créé.' }, 500)

      const { data: profile, error: profileError } = await adminClient
        .from('profiles')
        .update({ full_name: name, role, approved })
        .eq('id', created.user.id)
        .select('id,full_name,role,approved,created_at')
        .single()

      if (profileError) {
        await adminClient.auth.admin.deleteUser(created.user.id)
        return json({ error: `Profil non créé : ${profileError.message}` }, 500)
      }

      return json({ user: { id: created.user.id, email: created.user.email, ...profile } }, 201)
    }

    if (action === 'delete') {
      const id = String(body?.id ?? '')
      if (!id || id === user.id) return json({ error: 'Suppression impossible pour ce compte.' }, 400)
      const { error } = await adminClient.auth.admin.deleteUser(id)
      if (error) return json({ error: error.message }, 400)
      return json({ ok: true })
    }

    if (action === 'approve') {
      const id = String(body?.id ?? '')
      if (!id) return json({ error: 'Identifiant utilisateur manquant.' }, 400)
      const { data, error } = await adminClient.from('profiles').update({ approved: true }).eq('id', id).select('id,full_name,role,approved').single()
      if (error) return json({ error: error.message }, 400)
      return json({ user: data })
    }

    return json({ error: 'Action inconnue.' }, 400)
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : 'Erreur serveur.' }, 500)
  }
})

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
}
